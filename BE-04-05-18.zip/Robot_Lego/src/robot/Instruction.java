package robot;



import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import terrain.GrapheTerrain;
import terrain.Sommet;
import terrain.Triplet;

import lejos.nxt.Button;
import lejos.nxt.LCD;
import lejos.robotics.pathfinding.DijkstraPathFinder;

public class Instruction {
	
	public final static int FORWARD = 0;
	public final static int RIGHT = 1;
	public final static int LEFT = 2;
	public final static int FOLLOW = 3;
	public final static int STOP = 4;
	public final static int TURN_BACK = 5;
	public Travel travel;
	
	public Instruction(int speed){
		travel = new Travel(speed);
	}
	
	public void followInstruction(Integer instr){
		switch (instr.intValue()){
		case FORWARD : 
			travel.forward();
			break;
		case RIGHT :
			travel.right();
			break;
		case LEFT : 
			travel.left();
			break;
		case FOLLOW :
			travel.followLine();
			break;
		case STOP :
			travel.stop();
			break;
		case TURN_BACK :
			travel.turnBack();
			break;
		}
	}
	
	public void followInstructionList (List<Integer> instructionList){
		for (Integer instr: instructionList){
			followInstruction(instr);
		}
	}
	
//	public static void main(String[] args) {
//		Instruction instrs = new Instruction(300);
////		List<Integer> list = new ArrayList<Integer>();
////		list.add(Integer.valueOf(FORWARD));
////		list.add(Integer.valueOf(FOLLOW));
////		list.add(Integer.valueOf(RIGHT));
////		list.add(Integer.valueOf(FOLLOW));
////		list.add(Integer.valueOf(LEFT));
////		list.add(Integer.valueOf(FOLLOW));
////		list.add(Integer.valueOf(RIGHT));
////		list.add(Integer.valueOf(FOLLOW));
////		list.add(Integer.valueOf(LEFT));
////		list.add(Integer.valueOf(FOLLOW));
////		list.add(Integer.valueOf(RIGHT));
////		list.add(Integer.valueOf(FOLLOW));
////		list.add(Integer.valueOf(LEFT));
////		list.add(Integer.valueOf(FOLLOW));
////		list.add(Integer.valueOf(RIGHT));
////		list.add(Integer.valueOf(FOLLOW));
////		list.add(Integer.valueOf(LEFT));
////		list.add(Integer.valueOf(FOLLOW));
////		list.add(Integer.valueOf(RIGHT));
////		list.add(Integer.valueOf(FOLLOW));
////		list.add(Integer.valueOf(LEFT));
////		list.add(Integer.valueOf(FOLLOW));
////		list.add(Integer.valueOf(RIGHT));
////		list.add(Integer.valueOf(FOLLOW));
////		list.add(Integer.valueOf(LEFT));
////		list.add(Integer.valueOf(FOLLOW));
////		list.add(Integer.valueOf(RIGHT));
////		list.add(Integer.valueOf(FOLLOW));
////		list.add(Integer.valueOf(LEFT));
////		list.add(Integer.valueOf(FOLLOW));
////		list.add(Integer.valueOf(RIGHT));
////		list.add(Integer.valueOf(FOLLOW));
////		list.add(Integer.valueOf(LEFT));
////		list.add(Integer.valueOf(STOP));
//		
//		List <Integer> list = new ArrayList<Integer>();
//		list.add(FORWARD);
//		list.add(FOLLOW);
//		list.add(TURN_BACK);
//		list.add(FORWARD);
//		list.add(FOLLOW);
//		list.add(STOP);
//		Button.waitForAnyPress();
//		instrs.followInstructionList(list);
//	}
public static void main(String[] args) {
		
		
		int N = 12;//Nombre de sommet
		
		//Cr�ation du Graphe.
		GrapheTerrain graphe = new GrapheTerrain();
		//Graphe - Ajouts des Sommets.
		Sommet A = new Sommet(0,3);
		graphe.getGraphe().add(A);
		Sommet B = new Sommet(1,7.001);
		graphe.getGraphe().add(B);
		Sommet C = new Sommet(2,1.002);
		graphe.getGraphe().add(C);
		Sommet D = new Sommet(3,1.003);
		graphe.getGraphe().add(D);
		Sommet E = new Sommet(4,1.005);
		graphe.getGraphe().add(E);
		Sommet F = new Sommet(5,1.006);
		graphe.getGraphe().add(F);
		Sommet G = new Sommet(6,1.007);
		graphe.getGraphe().add(G);
		Sommet H = new Sommet(7,3.008);
		graphe.getGraphe().add(H);
		Sommet I = new Sommet(8,5.009);
		graphe.getGraphe().add(I);
		Sommet J = new Sommet(9,3.01);
		graphe.getGraphe().add(J);
		Sommet K = new Sommet(10,3.011);
		graphe.getGraphe().add(K);
		Sommet L = new Sommet(11,7.012);
		graphe.getGraphe().add(L);
		//Graphe - Ajout des Arcs.	
		boolean aGauche = true;
		boolean aDroite = false;

		graphe.addArc(0, 1, aDroite,1);
		graphe.addArc(0, 2, aGauche,1);
		graphe.addArc(0, 3, aDroite,2);
		graphe.addArc(0, 5, aGauche,2);

		graphe.addArc(1, 2, aDroite,1);
		graphe.addArc(1, 7, aGauche,6);
		graphe.addArc(1, 11, aDroite,6);
		
		graphe.addArc(2, 3, aGauche,3);
		graphe.addArc(2, 4, aDroite,3);
		
		graphe.addArc(3, 5, aDroite,2);
		graphe.addArc(3, 4, aGauche,3);
		
		graphe.addArc(4, 7, aDroite,4);
		graphe.addArc(4, 6, aGauche,4);
		
		graphe.addArc(5, 6, aDroite,5);
		graphe.addArc(5, 8, aGauche,5);
		
		graphe.addArc(6, 7, aGauche,4);
		graphe.addArc(6, 8, aDroite,5);
		
		graphe.addArc(7, 11, aGauche,6);
		
		graphe.addArc(8, 9, aDroite,8);
		graphe.addArc(8, 10, aGauche,8);
		
		graphe.addArc(9, 10, aGauche,7);
		graphe.addArc(9, 10, aDroite,8);
		graphe.addArc(9, 11, aDroite,7);
		
		graphe.addArc(10, 11, aGauche,7);

		
		List<Integer> list = GrapheTerrain.dijkstra ( 8, 10, 0, N, 8);
		Instruction inst = new Instruction(300);
		Button.waitForAnyPress();
		inst.followInstructionList(list);
	}
	
}
