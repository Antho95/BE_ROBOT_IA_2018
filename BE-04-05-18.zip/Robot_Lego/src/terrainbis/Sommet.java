package terrainbis;

import java.util.NavigableSet;
import java.util.TreeSet;

public class Sommet implements Comparable<Sommet> {
	
	private int index;
	private Intersection i1;
	private Intersection i2;
	
	public Sommet(int index){
		this.index = index;
		i1 = null;
		i2 = null;
	}
	
	public boolean addIntersection (Intersection inter){
		if (i1 == null){
			i1 = inter;
			return true;
		}
		if (i2 == null){
			i2 = inter;
			return true;
		}
		return false;
	}
	
	public NavigableSet<Sommet> getVoisins(){
		NavigableSet<Sommet> voisins = new TreeSet<Sommet>();
	}

	public int compareTo(Sommet o) {
		// TODO Auto-generated method stub
		return 0;
	}
}
