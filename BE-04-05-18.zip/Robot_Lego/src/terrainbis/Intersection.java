package terrainbis;

import java.util.ArrayList;
import java.util.List;

import robot.Instruction;

public class Intersection {
	private int index;
	private Sommet haut;
	private Sommet gauche;
	private Sommet droit;
	private int longueur;
	
	public Intersection(int index, Sommet haut, Sommet gauche, Sommet droit, int longueur){
		this.index = index;
		this.haut = haut;
		this.gauche = gauche;
		this.droit = droit;
		this.longueur = longueur;
	}
	
	public Sommet getDroit() {
		return droit;
	}
	
	public Sommet getGauche() {
		return gauche;
	}
	
	public Sommet getHaut() {
		return haut;
	}
	
	public int getLongueur() {
		return longueur;
	}
	
	public int chemin(Sommet source, Sommet destination){
		if(source.equals(haut)){
			if (destination.equals(droit)){
				return Instruction.RIGHT;
			}
			else{
				return Instruction.LEFT;
			}
		}
		if (source.equals(droit)){
			if (destination.equals(haut)){
				return Instruction.RIGHT;
			}
			else{
				return Instruction.LEFT;
			}
		}
		if (destination.equals(droit)){
			return Instruction.RIGHT;
		}
		else{
			return Instruction.LEFT;
		}
	}
	
	public List<Sommet> sommetSuivants(Sommet depart){
		ArrayList<Sommet> suivants = new ArrayList<Sommet>();
		if (depart.equals(haut)){
			suivants.add(gauche);
			suivants.add(droit);
			return suivants;
		}
		if (depart.equals(droit)){
			suivants.add(gauche);
			suivants.add(haut);
			return suivants;
		}
		suivants.add(haut);
		suivants.add(droit);
		return suivants;
	}
	
	public boolean equals(Object obj){
		if (obj != null && obj instanceof Intersection){
			Intersection intersect = (Intersection) obj;
			if (haut.equals(intersect.haut)
					&& droit.equals(intersect.droit) && 
					gauche.equals(intersect.gauche) && longueur == intersect.longueur){
				return true;
			}
		}
		return false;
	}
	
	
}
