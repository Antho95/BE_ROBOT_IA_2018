package Terrain;

import java.util.*;

public class GrapheTerrain {
		
	private static HashMap<Integer,Sommet> graphe = new HashMap<Integer,Sommet>();
	
	//Recuperer le sommet dans un graphe
	public static Sommet getSommet(int id) {
		
		return graphe.get(id);
		
	}

	public void addArc(int source, int destination, boolean gauche, int inter) {
		
		//recuperation des sommets correspondant
		Sommet s = getSommet(source);
		Sommet d = getSommet(destination);
		
		//cr�ation des arcs
		Triplet t1 = new Triplet(d,gauche,d.getL(), inter);
		Triplet t2 = new Triplet(s,!gauche,s.getL(), inter);
		
		//memorisation dans les tableau d'adjacense de chaque sommet
		s.adjacent.add(t1);
		d.adjacent.add(t2);
		
	}
	
	public HashMap<Integer,Sommet> getGraphe (){
		
		return graphe;
		
	}
	
	public static void main(String[] args) {
		
		
		int N = 12;//Nombre de sommet
		
		//Cr�ation du Graphe.
		GrapheTerrain graphe = new GrapheTerrain();
		
		//Graphe - Ajouts des Sommets.
		Sommet A = new Sommet(0,3);
		graphe.getGraphe().put(0,A);
		Sommet B = new Sommet(1,7.001);
		graphe.getGraphe().put(1,B);
		Sommet C = new Sommet(2,1.002);
		graphe.getGraphe().put(2,C);
		Sommet D = new Sommet(3,1.003);
		graphe.getGraphe().put(3,D);
		Sommet E = new Sommet(4,1.005);
		graphe.getGraphe().put(4,E);
		Sommet F = new Sommet(5,1.006);
		graphe.getGraphe().put(5,F);
		Sommet G = new Sommet(6,1.007);
		graphe.getGraphe().put(6,G);
		Sommet H = new Sommet(7,3.008);
		graphe.getGraphe().put(7,H);
		Sommet I = new Sommet(8,5.009);
		graphe.getGraphe().put(8,I);
		Sommet J = new Sommet(9,3.01);
		graphe.getGraphe().put(9,J);
		Sommet K = new Sommet(10,3.011);
		graphe.getGraphe().put(10,K);
		Sommet L = new Sommet(11,7.012);
		graphe.getGraphe().put(11,L);
		
		//Graphe - Ajout des Arcs.	
		boolean aGauche = true;
		boolean aDroite = false;

		graphe.addArc(0, 1, aDroite,1);
		graphe.addArc(0, 2, aGauche,1);
		graphe.addArc(0, 3, aDroite,2);
		graphe.addArc(0, 5, aGauche,2);

		graphe.addArc(1, 2, aDroite,1);
		graphe.addArc(1, 7, aGauche,6);
		graphe.addArc(1, 11, aDroite,6);
		
		graphe.addArc(2, 3, aGauche,3);
		graphe.addArc(2, 4, aDroite,3);
		
		graphe.addArc(3, 5, aDroite,2);
		graphe.addArc(3, 4, aGauche,3);
		
		graphe.addArc(4, 7, aDroite,4);
		graphe.addArc(4, 6, aGauche,4);
		
		graphe.addArc(5, 6, aDroite,5);
		graphe.addArc(5, 8, aGauche,5);
		
		graphe.addArc(6, 7, aGauche,4);
		graphe.addArc(6, 8, aDroite,5);
		
		graphe.addArc(7, 11, aGauche,6);
		
		graphe.addArc(8, 9, aDroite,8);
		graphe.addArc(8, 10, aGauche,8);
		
		graphe.addArc(9, 10, aGauche,7);
		graphe.addArc(9, 10, aDroite,8);
		graphe.addArc(9, 11, aDroite,7);
		
		graphe.addArc(10, 11, aGauche,7);
		
		//////////////////////////////////////////////////////////////////////////////////////////
		LinkedList<Integer> resultats = new LinkedList<>();
		resultats = dijkstra( 6, 10, 0, N, 6);
		

		for(int i =0; i<resultats.size() ;i++) {
			System.out.print(" -> "+ resultats.get(i));
		}System.out.println();
		
		
		//////////////////////////////////////////////////////////////////////////////////////////

	}
	

	//Permet de trouver le sommet le plus proche d'un autre si il n'est pas visited
	public static int sommetLePlusProche (double[] distance, int[] visited, int N) {
		int somProche = -1;
		for(int i = 0 ; i < N; i++) {
			if (visited[i] != 1 && (somProche ==-1 || distance[i] < distance[somProche]))
				somProche = i;
		}
		return somProche;
	}
	//Permet de recuperer la direction
	public static Triplet getArcTriplet (Sommet s1,Sommet s2) {
		for (Triplet t : s1.adjacent)
			if(t.getPremier() == s2)
				return t;
		Triplet T = new Triplet(s1,false , 9999, 9999);
		return T;
	}
	
	//Permet la fin de dijkstra
	public static boolean tousVisited(int[] visited) {
		boolean res = true;
		for(int i =0; i< visited.length ; i++) {
			if(visited[i]==0)
				res = false;
		}
		return res;
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////
	
	public static LinkedList<Integer> dijkstra ( int depart, int victime1, int hopital, int N, int dernierInterVisite){
		
		
		double [][] matrix = new double [N][N];//Matrice pour appliquer algo de recherche
		
		double [] distance = new double [N];//Memoriser la distance de chaque chemin
		
		Triplet [] pred = new Triplet [N];//Memorisation du predecesseur
		LinkedList<Integer> intersection = new LinkedList<>();
		
		int [] visited = new int [N];//Memorisation des sommets visited
		
		LinkedList<Integer> res = new LinkedList<>();
		int sommetDepart = -1;
		int sommetArrive = -1;
		int dV = -1;
		
		//initialisation de la matrice - INFINI
				for(int i = 0; i<N ; i++){
					for(int j = 0; j<N ; j++){
						matrix[i][j] = 9999;
					}
				}

		for(int v = 0 ; v < 2 ; v++) {	//Calculs : depart -> v1 ; v1 -> hopital ;
			if (v==1) {
				sommetDepart = depart;
				sommetArrive = victime1;
			}
			if (v==0) {
				sommetDepart = victime1;
				sommetArrive = hopital;
			}

			visited[sommetDepart] = 1; //Sommet de depart - visited
			
			//Recuperation des distances des somAdjacent au sommet de depart
			for(int i=0;i<N;i++) {
				distance[i] = matrix[sommetDepart][i];
			}distance[sommetDepart] = 0;
			
			//Initialisation de la matrice avec les bonnes valeurs
			
			for (int i = 0; i<N ; i++) { //Pour chaque sommet
				
				pred[i] = getArcTriplet(getSommet(i), getSommet(sommetDepart)); //initialisation 
				visited[i] = 0; //initialisation a 0
				Sommet somVoisin = getSommet(i); //Sommet i
				
				for (Triplet t: somVoisin.adjacent) { //Pour ses sommets adjacents
					
					int idVoisin = (t.getPremier()).getS(); //Prend l'id du sommet adjacent correspondant
					matrix[i][idVoisin] = t.getTroisieme(); //Memorise le poid de l'arc i vers idVoisin
					
				}
			}
			
			//ALGO Dj
			
			visited[sommetDepart] = 1; //Sommet de depart - visited
			
			//Recuperation des distances des somAdjacent au sommet de depart
			for(int i=0;i<N;i++) {
				distance[i] = matrix[sommetDepart][i];
			}distance[sommetDepart] = 0;
	
			//DIJKSTRA 
			while(!tousVisited(visited)) {
				
				int somProche = sommetLePlusProche(distance, visited, N); // Recherche du sommet le plus proche
				Sommet sommetS = getSommet(somProche);
				visited[somProche] = 1;  // Sommet le plus proche - visited
				
				for(Triplet t : sommetS.adjacent) { // pour tout les sommet adjacent a somProche
					
					int j = t.getPremier().getS();//recuperation du numero de sommet voisin
					Sommet sommetD = t.getPremier();
					
					if(matrix[somProche][j] != 9999 && visited[j] != 1) { //si il existe un arc && n'est pas visited
						
						double newDist = distance[somProche] + matrix[somProche][j]; // distance au sommet destination
						
						if(newDist < distance[j]) {
							
							distance[j] = newDist; // Memorisation de la dist
							pred[j] = getArcTriplet(sommetD, sommetS); //getArcTriplet(sommetD,getSommet(j)); // Memorisation du pred
							
						}
					}
				}	
			}
			
			int k = -1 ;
			
			//////////////////////////////////////////////////////////////////////////////////////////
			
			//Avancer = 0; Gauche = 2; Droite = 1; SuivreLigne = 3; Stop = 4; DemiTour = 5; 
			int j=sommetArrive;
			do {
				k = j;
				j = pred[j].getPremier().getS();
//				res.addFirst(3);
				if (getArcTriplet(getSommet(j), getSommet(k)).getSecond())
					res.addFirst(2);
				else 
					res.addFirst(1);

				dV = getArcTriplet(getSommet(j), getSommet(k)).getQuatrieme();
				intersection.addFirst(dV);
				
			}while (j != sommetDepart);
		}//v
		
		//Ajout des demi tour
		int nb5 = 0;
		for(int i = 0 ; i < intersection.size()-1; i++) {
			if(intersection.get(i)==intersection.get(i+1)) {
				res.add(nb5 + 2*i,5);
				nb5++;
			}
		}
		
		if(intersection.getFirst() == dernierInterVisite)
			res.addFirst(5);
		
		for(int i = intersection.size()+1 ; i >= 0; i--) {
				res.add(i,3);
		}
		
		for(int i = 0; i< intersection.size();i++)
			System.out.println(intersection.get(i));
		res.addFirst(0);
		res.add(4);
		return res;
	}

}
