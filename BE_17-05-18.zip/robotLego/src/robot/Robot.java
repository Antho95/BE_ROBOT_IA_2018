package robot;

import java.util.LinkedList;
import java.util.List;

import tableItineraire.Itineraire;

public class Robot {
	
	private int identifiant;
	private int position;
	private int dernierInter;
	private Itineraire itineraire;
	private int instruction;
	private int nbPorte;
	
	public Robot(int id, int position, int dernierInter){
		this.identifiant = id;
		this.position = position;
		this.dernierInter = dernierInter;
		List<Integer> inst = new LinkedList<Integer>();
		inst.add(Instruction.FORWARD);
		inst.add(Instruction.FOLLOW);
		inst.add(Instruction.STOP);
		this.itineraire = new Itineraire(dernierInter, dernierInter, inst , 0);
		this.instruction = -1;
		this.nbPorte = 0;
	}
	
	public Robot(Robot r){
		this.identifiant = r.identifiant;
		this.position = r.position;
		this.dernierInter = r.dernierInter;
		this.itineraire = new Itineraire(r.itineraire.getPremierInter(), r.itineraire.getDerniereInter(), r.itineraire.getInstructions(), r.itineraire.getDistance(),r.itineraire.getDepart());
		this.instruction = r.instruction;
		this.nbPorte = r.nbPorte;
	}
	
	public Robot(Robot r,Itineraire itin){
		this.identifiant = r.identifiant;
		this.position = r.position;
		this.dernierInter = r.dernierInter;
		this.itineraire = Itineraire.concatener(r.itineraire, itin);
		this.instruction = r.instruction;
		this.nbPorte = r.nbPorte;
	}
	
	public Robot(){
		itineraire = new Itineraire(-1, -1, null, 9999);
	}
	
	public int getIdentifiant() {
		return identifiant;
	}
	
	public int getNbPorte() {
		return nbPorte;
	}
	
	public Itineraire getItineraire() {
		return itineraire;
	}
	
	public int getInstruction() {
		return instruction;
	}
	
	public int getPosition() {
		return position;
	}
	
	public int getDernierInter() {
		return dernierInter;
	}

	public static boolean inferieur(List<Robot> robots1, List<Robot> robots2) {
		int dist1 = 0;
		int dist2 = 0;
		for (Robot r : robots1){
			dist1 += r.itineraire.getDistance();
		}
		for (Robot r : robots2){
			dist2 += r.itineraire.getDistance();
		}
		return dist1 < dist2;
	}
	
	public void incrementerNbPorte(){
		++nbPorte;
	}
	
	public void setZeroNbPorte(){
		nbPorte = 0;
	}
}
